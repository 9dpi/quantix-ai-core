"""
Primitives package - Individual feature calculators
"""

# StructurePrimitive moved to learning.primitives
from quantix_core.learning.primitives.structure import StructurePrimitive

__all__ = ['StructurePrimitive']
